package com.example.jarvis

import ai.picovoice.porcupine.Porcupine
import ai.picovoice.porcupine.PorcupineManager
import ai.picovoice.porcupine.PorcupineManagerCallback
import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

class JarvisService : AccessibilityService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var job: Job? = null
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private var bubble: Button? = null
    private val nodes = mutableListOf<AccessibilityNodeInfo>()
    private var porcupine: PorcupineManager? = null
    private val prefs get() = getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "wake_word" || key == "picovoice_key") { stopWakeWord(); syncWakeWord() }
    }

    companion object {
        private const val MAX_STEPS = 15
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) tts?.language = Locale.getDefault() }
        addBubble()
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
        syncWakeWord()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        stopWakeWord()
        job?.cancel()
        recognizer?.destroy()
        tts?.shutdown()
        bubble?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) }
        super.onDestroy()
    }

    // ---------- UI bubble ----------

    private fun addBubble() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val b = Button(this).apply {
            text = "🎙"
            textSize = 22f
            setOnClickListener { onBubbleTapped() }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL }
        wm.addView(b, lp)
        bubble = b
    }

    private fun setBubble(text: String) { bubble?.text = text }

    private fun onBubbleTapped() {
        if (job?.isActive == true) {
            job?.cancel()
            tts?.stop()
            idle()
            speak("Stopped")
            return
        }
        listen { command -> runCommand(command) }
    }

    // ---------- Wake word ("Jarvis") ----------

    private fun idle() {
        setBubble("🎙")
        syncWakeWord()
    }

    private fun syncWakeWord() {
        if (prefs.getBoolean("wake_word", false)) {
            startWakeWord()
        } else {
            stopWakeWord()
            stopForeground(STOP_FOREGROUND_REMOVE)
        }
    }

    private fun startWakeWord() {
        if (porcupine != null) return
        val key = prefs.getString("picovoice_key", "") ?: ""
        if (key.isBlank() ||
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED
        ) return
        try {
            startAsForeground()
            porcupine = PorcupineManager.Builder()
                .setAccessKey(key)
                .setKeyword(Porcupine.BuiltInKeyword.JARVIS)
                .build(this, PorcupineManagerCallback { _ -> scope.launch { onWake() } })
            porcupine?.start()
        } catch (e: Exception) {
            porcupine = null
            speak("Wake word failed. ${e.message?.take(60)}")
        }
    }

    // Stops mic use but keeps the foreground notification so we can restart later.
    private fun stopWakeWord() {
        try { porcupine?.stop(); porcupine?.delete() } catch (_: Exception) {}
        porcupine = null
    }

    private fun onWake() {
        if (job?.isActive == true) return
        stopWakeWord()
        ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80).startTone(ToneGenerator.TONE_PROP_BEEP, 150)
        scope.launch {
            delay(350)
            listen { command -> runCommand(command) }
        }
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("jarvis", "Jarvis wake word", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "jarvis")
            .setContentTitle("Jarvis is listening for \"Jarvis\"")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
    }

    // ---------- Voice ----------

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    private fun listen(onResult: (String) -> Unit) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            speak("Open the Jarvis app and grant microphone permission.")
            return
        }
        stopWakeWord()
        recognizer?.destroy()
        setBubble("👂")
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle?) {
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (text.isNullOrBlank()) idle() else onResult(text)
                }
                override fun onError(error: Int) { idle() }
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            })
        }
    }

    // ---------- Agent loop ----------

    private fun runCommand(goal: String) {
        val apiKey = getSharedPreferences("jarvis", Context.MODE_PRIVATE).getString("api_key", "") ?: ""
        if (apiKey.isBlank()) { speak("Please save your API key in the Jarvis app."); idle(); return }

        job = scope.launch {
            val history = mutableListOf<String>()
            try {
                setBubble("⏳")
                for (step in 1..MAX_STEPS) {
                    delay(1000) // let the UI settle
                    val screen = snapshot()
                    val action = withContext(Dispatchers.IO) {
                        ClaudeClient.nextAction(apiKey, goal, history, screen)
                    }
                    history.add(action.toString())
                    when (action.optString("action")) {
                        "open_app" -> if (!openApp(action.optString("app"))) history.add("(app not found)")
                        "click" -> if (!click(action.optInt("index", -1))) history.add("(click failed)")
                        "type" -> if (!typeText(action.optInt("index", -1), action.optString("text"))) history.add("(type failed)")
                        "enter" -> pressEnter()
                        "scroll" -> scroll(action.optString("direction") != "up")
                        "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
                        "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
                        "wait" -> delay(1500)
                        "done" -> { speak(action.optString("say", "Done")); return@launch }
                        else -> { speak("I got confused."); return@launch }
                    }
                }
                speak("That took too many steps, so I stopped.")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                speak("Error. ${e.message?.take(80)}")
            } finally {
                idle()
            }
        }
    }

    // ---------- Screen reading ----------

    private fun snapshot(): String {
        nodes.clear()
        val root = rootInActiveWindow ?: return "(screen not available)"
        val sb = StringBuilder("App package: ${root.packageName}\n")

        fun walk(n: AccessibilityNodeInfo) {
            if (!n.isVisibleToUser) return
            val label = listOfNotNull(n.text, n.contentDescription).joinToString(" | ")
            if (label.isNotBlank() || n.isClickable || n.isEditable || n.isScrollable) {
                val flags = buildList {
                    if (n.isClickable) add("tap")
                    if (n.isEditable) add("input")
                    if (n.isScrollable) add("scroll")
                }
                val cls = n.className?.toString()?.substringAfterLast('.') ?: "View"
                sb.append("[${nodes.size}] $cls \"${label.take(80)}\" $flags\n")
                nodes.add(n)
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it) }
        }
        walk(root)
        return sb.toString().take(12000)
    }

    // ---------- Actions ----------

    private fun openApp(name: String): Boolean {
        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
        val match = apps.firstOrNull { it.loadLabel(pm).toString().equals(name, true) }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().contains(name, true) }
            ?: return false
        val intent = pm.getLaunchIntentForPackage(match.activityInfo.packageName) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
        return true
    }

    private fun click(index: Int): Boolean {
        val node = nodes.getOrNull(index) ?: return false
        var n: AccessibilityNodeInfo? = node
        while (n != null && !n.isClickable) n = n.parent
        if (n != null && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        // Fallback: tap the center of the element
        val r = Rect().also { node.getBoundsInScreen(it) }
        return tapAt(r.exactCenterX(), r.exactCenterY())
    }

    private fun tapAt(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 50))
            .build()
        return dispatchGesture(g, null, null)
    }

    private fun typeText(index: Int, text: String): Boolean {
        val node = nodes.getOrNull(index) ?: return false
        node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun pressEnter() {
        if (Build.VERSION.SDK_INT >= 30) {
            val focused = findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            focused?.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        }
    }

    private fun scroll(down: Boolean) {
        val target = nodes.firstOrNull { it.isScrollable } ?: return
        target.performAction(
            if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        )
    }
}
