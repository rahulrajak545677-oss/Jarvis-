package com.example.jarvis

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object ClaudeClient {
    private const val MODEL = "claude-sonnet-5-5"
    private const val URL_API = "https://api.anthropic.com/v1/messages"

    private val SYSTEM = """
You control an Android phone on behalf of the user through an accessibility service.
Each turn you get the user's goal, the actions already taken, and the current screen as a
numbered list of elements. Reply with exactly ONE JSON object and nothing else.

Actions:
{"action":"open_app","app":"WhatsApp"}
{"action":"click","index":12}
{"action":"type","index":5,"text":"hello"}
{"action":"enter"}                          press Enter/Search on the keyboard
{"action":"scroll","direction":"down"}      or "up"
{"action":"back"}
{"action":"home"}
{"action":"wait"}
{"action":"done","say":"Short spoken reply to the user"}

Rules:
- Use element indices from the CURRENT screen only; they change every turn.
- Prefer the fewest steps. If the goal is complete, or impossible, reply with done.
- NEVER complete payments, purchases, deletions, or send messages the user did not
  explicitly dictate. Instead reply done and ask the user to confirm by voice.
- Never enter passwords or OTPs. Stop and tell the user.
- Keep "say" under 20 words.
""".trimIndent()

    fun nextAction(apiKey: String, goal: String, history: List<String>, screen: String): JSONObject {
        val userText = buildString {
            append("Goal: ").append(goal).append("\n\n")
            append("Actions so far:\n")
            if (history.isEmpty()) append("(none)\n") else history.takeLast(8).forEach { append("- ").append(it).append('\n') }
            append("\nCurrent screen:\n").append(screen)
        }
        val body = JSONObject()
            .put("model", MODEL)
            .put("max_tokens", 300)
            .put("system", SYSTEM)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", userText)))

        val conn = (URL(URL_API).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 60000
            doOutput = true
            setRequestProperty("content-type", "application/json")
            setRequestProperty("x-api-key", apiKey)
            setRequestProperty("anthropic-version", "2023-06-01")
        }
        conn.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = conn.responseCode
        val text = (if (code in 200..299) conn.inputStream else conn.errorStream).bufferedReader().readText()
        if (code !in 200..299) throw RuntimeException("API $code: ${text.take(200)}")

        val reply = JSONObject(text).getJSONArray("content").getJSONObject(0).getString("text")
        val start = reply.indexOf('{')
        val end = reply.lastIndexOf('}')
        if (start < 0 || end < start) throw RuntimeException("Bad reply: ${reply.take(100)}")
        return JSONObject(reply.substring(start, end + 1))
    }
}
