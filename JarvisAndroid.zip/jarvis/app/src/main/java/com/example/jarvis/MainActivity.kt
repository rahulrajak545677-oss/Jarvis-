package com.example.jarvis

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("jarvis", Context.MODE_PRIVATE)

        val info = TextView(this).apply {
            text = "1. Paste your Anthropic API key and save.\n" +
                "2. Grant microphone + notification permission.\n" +
                "3. Enable Jarvis in Accessibility settings.\n" +
                "4. Tap the \uD83C\uDF99 bubble, or turn on the wake word and say \"Jarvis\".\n\n" +
                "Wake word needs a free AccessKey from console.picovoice.ai."
            textSize = 15f
        }
        val keyInput = EditText(this).apply {
            hint = "Anthropic API key (sk-ant-...)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("api_key", ""))
        }
        val pvInput = EditText(this).apply {
            hint = "Picovoice AccessKey (for wake word)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("picovoice_key", ""))
        }
        val save = Button(this).apply {
            text = "Save keys"
            setOnClickListener {
                prefs.edit()
                    .putString("api_key", keyInput.text.toString().trim())
                    .putString("picovoice_key", pvInput.text.toString().trim())
                    .apply()
                Toast.makeText(this@MainActivity, "Saved", Toast.LENGTH_SHORT).show()
            }
        }
        val wake = Switch(this).apply {
            text = "Wake word: say \"Jarvis\""
            isChecked = prefs.getBoolean("wake_word", false)
            setOnCheckedChangeListener { _, on ->
                prefs.edit()
                    .putString("picovoice_key", pvInput.text.toString().trim())
                    .putBoolean("wake_word", on)
                    .apply()
            }
        }
        val mic = Button(this).apply {
            text = "Grant permissions"
            setOnClickListener {
                requestPermissions(
                    arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), 1
                )
            }
        }
        val acc = Button(this).apply {
            text = "Open Accessibility settings"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
            listOf(info, keyInput, pvInput, save, wake, mic, acc).forEach { addView(it) }
        })
    }
}
