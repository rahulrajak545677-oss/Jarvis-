# Jarvis for Android

Voice-controlled phone agent: speech -> Claude -> Accessibility actions.

## Build
1. Open this folder in Android Studio (Koala or newer). Let Gradle sync (it creates the wrapper).
2. Run on a physical phone (Android 8.0+). Emulators often lack speech recognition.
3. In the app: save your Anthropic API key, grant mic permission, enable "Jarvis" in Accessibility settings.
4. Tap the mic bubble on the right edge of any screen and speak. Tap again to stop.

## Notes
- Model name is set in ClaudeClient.kt (MODEL).
- API key is in SharedPreferences; for a real release use EncryptedSharedPreferences or a backend proxy.
- Each step sends the screen text to Anthropic's API, so avoid using it on private screens.
- Banking and some secure apps block accessibility access.

## Wake word
- Uses Picovoice Porcupine's built-in "Jarvis" keyword (not "Hey Jarvis"; that needs a custom .ppn from the Picovoice console).
- Get a free AccessKey at console.picovoice.ai, paste it in the app, then turn on the switch while the app is open.
- Runs as a foreground service with a persistent notification and uses extra battery.
- Wake word pauses while Jarvis is listening or working, then resumes.
